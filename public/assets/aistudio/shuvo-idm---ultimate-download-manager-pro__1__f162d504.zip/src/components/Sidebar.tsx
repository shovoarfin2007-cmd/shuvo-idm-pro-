import React from 'react';
import {
  Folder,
  Video,
  Music,
  FileText,
  Package,
  Radio,
  PlayCircle,
  PauseCircle,
  CheckCircle2,
  XCircle,
  HardDrive,
  UserCheck,
  Phone,
  MessageCircle,
  Sparkles,
  KeyRound,
  Clock,
} from 'lucide-react';
import { DownloadCategory, DownloadItem, DownloadStatus } from '../types/idm';
import { formatBytes } from '../utils/license';

interface SidebarProps {
  selectedCategory: DownloadCategory;
  onSelectCategory: (cat: DownloadCategory) => void;
  statusFilter: DownloadStatus | 'all';
  onSelectStatusFilter: (status: DownloadStatus | 'all') => void;
  downloads: DownloadItem[];
  saveFolder: string;
  onContactClick: () => void;
  onKeygenClick: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  selectedCategory,
  onSelectCategory,
  statusFilter,
  onSelectStatusFilter,
  downloads,
  saveFolder,
  onContactClick,
  onKeygenClick,
}) => {
  // Compute counts
  const categoryCounts = {
    all: downloads.length,
    videos: downloads.filter((d) => d.category === 'videos').length,
    music: downloads.filter((d) => d.category === 'music').length,
    documents: downloads.filter((d) => d.category === 'documents').length,
    programs: downloads.filter((d) => d.category === 'programs').length,
    torrents: downloads.filter((d) => d.category === 'torrents').length,
  };

  const statusCounts = {
    downloading: downloads.filter((d) => d.status === 'downloading').length,
    queued: downloads.filter((d) => d.status === 'queued').length,
    paused: downloads.filter((d) => d.status === 'paused').length,
    completed: downloads.filter((d) => d.status === 'completed').length,
    failed: downloads.filter((d) => d.status === 'failed' || d.status === 'stopped').length,
  };

  const totalBytesDownloaded = downloads.reduce((acc, curr) => acc + curr.downloadedBytes, 0);

  const categories: { id: DownloadCategory; label: string; icon: React.ReactNode; color: string }[] = [
    { id: 'all', label: 'All Downloads', icon: <Folder className="w-4 h-4" />, color: 'text-blue-400' },
    { id: 'videos', label: 'Videos & Reels', icon: <Video className="w-4 h-4" />, color: 'text-rose-400' },
    { id: 'music', label: 'Music & Audio', icon: <Music className="w-4 h-4" />, color: 'text-emerald-400' },
    { id: 'documents', label: 'Documents', icon: <FileText className="w-4 h-4" />, color: 'text-amber-400' },
    { id: 'programs', label: 'Programs & Files', icon: <Package className="w-4 h-4" />, color: 'text-cyan-400' },
    { id: 'torrents', label: 'Torrents & Feeds', icon: <Radio className="w-4 h-4" />, color: 'text-purple-400' },
  ];

  return (
    <aside className="w-64 bg-slate-900/95 border-r border-slate-800 text-slate-300 flex flex-col justify-between shrink-0 select-none text-xs">
      <div className="overflow-y-auto p-3 space-y-4">
        {/* Categories Section */}
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-1.5 flex items-center justify-between">
            <span>Categories</span>
            <span className="text-[10px] text-slate-500 font-mono font-normal">
              {downloads.length} total
            </span>
          </div>
          <div className="space-y-0.5">
            {categories.map((cat) => {
              const active = selectedCategory === cat.id && statusFilter === 'all';
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    onSelectCategory(cat.id);
                    onSelectStatusFilter('all');
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md transition-all ${
                    active
                      ? 'bg-blue-600/20 text-blue-300 font-medium border border-blue-500/40'
                      : 'hover:bg-slate-800/80 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={cat.color}>{cat.icon}</span>
                    <span>{cat.label}</span>
                  </div>
                  <span
                    className={`font-mono text-[10px] px-1.5 py-0.2 rounded ${
                      active ? 'bg-blue-500 text-white font-bold' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {categoryCounts[cat.id]}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Status Filters */}
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-1.5">
            Queue Status
          </div>
          <div className="space-y-0.5">
            <button
              onClick={() => onSelectStatusFilter('downloading')}
              className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md transition-all ${
                statusFilter === 'downloading'
                  ? 'bg-sky-600/20 text-sky-300 font-medium border border-sky-500/40'
                  : 'hover:bg-slate-800/80 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-2">
                <PlayCircle className="w-4 h-4 text-sky-400 animate-pulse" />
                <span>Active Downloading</span>
              </div>
              <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-sky-950 text-sky-300 border border-sky-800">
                {statusCounts.downloading}
              </span>
            </button>

            <button
              onClick={() => onSelectStatusFilter('queued')}
              className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md transition-all ${
                statusFilter === 'queued'
                  ? 'bg-indigo-600/20 text-indigo-300 font-medium border border-indigo-500/40'
                  : 'hover:bg-slate-800/80 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-400" />
                <span>Queued (Smart Queue)</span>
              </div>
              <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                {statusCounts.queued}
              </span>
            </button>

            <button
              onClick={() => onSelectStatusFilter('paused')}
              className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md transition-all ${
                statusFilter === 'paused'
                  ? 'bg-amber-600/20 text-amber-300 font-medium border border-amber-500/40'
                  : 'hover:bg-slate-800/80 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-2">
                <PauseCircle className="w-4 h-4 text-amber-400" />
                <span>Paused</span>
              </div>
              <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-amber-950 text-amber-300 border border-amber-800">
                {statusCounts.paused}
              </span>
            </button>

            <button
              onClick={() => onSelectStatusFilter('completed')}
              className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md transition-all ${
                statusFilter === 'completed'
                  ? 'bg-emerald-600/20 text-emerald-300 font-medium border border-emerald-500/40'
                  : 'hover:bg-slate-800/80 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Completed</span>
              </div>
              <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                {statusCounts.completed}
              </span>
            </button>

            <button
              onClick={() => onSelectStatusFilter('failed')}
              className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md transition-all ${
                statusFilter === 'failed'
                  ? 'bg-rose-600/20 text-rose-300 font-medium border border-rose-500/40'
                  : 'hover:bg-slate-800/80 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-2">
                <XCircle className="w-4 h-4 text-rose-400" />
                <span>Stopped / Failed</span>
              </div>
              <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-rose-950 text-rose-300 border border-rose-800">
                {statusCounts.failed}
              </span>
            </button>
          </div>
        </div>

        {/* Disk & Storage Info */}
        <div className="bg-slate-800/60 border border-slate-700/60 rounded-lg p-2.5 space-y-1.5">
          <div className="flex items-center gap-2 text-slate-400 font-medium">
            <HardDrive className="w-3.5 h-3.5 text-cyan-400" />
            <span>Virtual Storage Pool</span>
          </div>
          <div className="flex justify-between text-[11px]">
            <span className="text-slate-400">Total Downloaded:</span>
            <span className="font-mono text-cyan-300 font-bold">
              {formatBytes(totalBytesDownloaded)}
            </span>
          </div>
          <div className="text-[10px] text-slate-400 truncate" title={saveFolder}>
            Path: <span className="font-mono text-slate-300">{saveFolder}</span>
          </div>
        </div>
      </div>

      {/* Bottom Shuvo Bhai Watermark & Contact Card */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/80 space-y-2">
        <div className="bg-gradient-to-r from-emerald-950/60 via-slate-900 to-blue-950/60 border border-emerald-500/40 rounded-lg p-2.5 shadow-sm">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-1.5 font-bold text-emerald-400 text-[11px]">
              <UserCheck className="w-3.5 h-3.5" />
              <span>Shuvo Bhai Official</span>
            </div>
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
          </div>

          <p className="text-[10px] text-slate-300 leading-tight mb-2">
            Licensed & Maintained by <strong className="text-white">SM Shuvo</strong>. For instant key, contact:
          </p>

          <div className="flex items-center justify-between gap-1 pt-1 border-t border-slate-800">
            <a
              href="tel:01997966529"
              className="flex items-center gap-1 text-[11px] font-mono font-bold text-cyan-300 hover:text-cyan-200 transition-colors"
            >
              <Phone className="w-3 h-3 text-cyan-400" />
              <span>01997966529</span>
            </a>
            <button
              onClick={onContactClick}
              className="flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 text-[10px] font-medium border border-emerald-500/50 transition-all"
            >
              <MessageCircle className="w-3 h-3" />
              <span>Support</span>
            </button>
          </div>

          <button
            onClick={onKeygenClick}
            className="w-full mt-2 flex items-center justify-center gap-1.5 py-1 rounded bg-purple-950/70 hover:bg-purple-900 border border-purple-700/60 text-purple-300 text-[10px] font-semibold transition-all cursor-pointer"
            title="Open Author Standalone Keygen (SM Shuvo Only)"
          >
            <KeyRound className="w-3 h-3 text-purple-400" />
            <span>Author Keygen Software</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
