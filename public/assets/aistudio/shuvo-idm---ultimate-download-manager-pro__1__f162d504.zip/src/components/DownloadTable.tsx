import React, { useState, useEffect } from 'react';
import {
  Video,
  Music,
  FileText,
  Package,
  Radio,
  File,
  Play,
  Pause,
  RotateCcw,
  Square,
  Trash2,
  ExternalLink,
  Search,
  Filter,
  CheckSquare,
  Square as EmptySquare,
  Copy,
  Info,
  Download,
  FolderOpen,
} from 'lucide-react';
import { DownloadItem, DownloadCategory, DownloadStatus, DownloadPriority } from '../types/idm';
import { formatBytes, formatSpeed, formatDuration } from '../utils/license';
import { PRIORITY_LABELS } from '../utils/queue';

interface DownloadTableProps {
  downloads: DownloadItem[];
  selectedIds: string[];
  onToggleSelect: (id: string) => void;
  onSelectAll: () => void;
  onClearSelection: () => void;
  onInspectItem: (item: DownloadItem) => void;
  onTogglePauseItem: (item: DownloadItem) => void;
  onStopItem: (item: DownloadItem) => void;
  onRedownloadItem: (item: DownloadItem) => void;
  onDeleteItem: (id: string) => void;
  onSaveToDisk: (item: DownloadItem) => void;
  onPasteAndDownload: () => void;
  onOpenFolder: () => void;
  onChangePriority: (id: string, priority: DownloadPriority) => void;
}

export const DownloadTable: React.FC<DownloadTableProps> = ({
  downloads,
  selectedIds,
  onToggleSelect,
  onSelectAll,
  onClearSelection,
  onInspectItem,
  onTogglePauseItem,
  onStopItem,
  onRedownloadItem,
  onDeleteItem,
  onSaveToDisk,
  onPasteAndDownload,
  onOpenFolder,
  onChangePriority,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [contextMenu, setContextMenu] = useState<{
    visible: boolean;
    x: number;
    y: number;
    item: DownloadItem | null;
  }>({
    visible: false,
    x: 0,
    y: 0,
    item: null,
  });

  // Close context menu on external click
  useEffect(() => {
    const handleOutsideClick = () => {
      if (contextMenu.visible) {
        setContextMenu((prev) => ({ ...prev, visible: false }));
      }
    };
    window.addEventListener('click', handleOutsideClick);
    return () => window.removeEventListener('click', handleOutsideClick);
  }, [contextMenu.visible]);

  const filteredDownloads = downloads.filter((d) =>
    d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.url.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (d.resolution && d.resolution.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const allSelected =
    filteredDownloads.length > 0 &&
    filteredDownloads.every((d) => selectedIds.includes(d.id));

  const handleRowContextMenu = (e: React.MouseEvent, item: DownloadItem) => {
    e.preventDefault();
    if (!selectedIds.includes(item.id)) {
      onToggleSelect(item.id);
    }
    setContextMenu({
      visible: true,
      x: Math.min(e.clientX, window.innerWidth - 220),
      y: Math.min(e.clientY, window.innerHeight - 300),
      item,
    });
  };

  const getCategoryIcon = (category: DownloadCategory) => {
    switch (category) {
      case 'videos':
        return <Video className="w-4 h-4 text-rose-400" />;
      case 'music':
        return <Music className="w-4 h-4 text-emerald-400" />;
      case 'documents':
        return <FileText className="w-4 h-4 text-amber-400" />;
      case 'programs':
        return <Package className="w-4 h-4 text-cyan-400" />;
      case 'torrents':
        return <Radio className="w-4 h-4 text-purple-400" />;
      default:
        return <File className="w-4 h-4 text-slate-400" />;
    }
  };

  const getStatusBadge = (status: DownloadStatus) => {
    switch (status) {
      case 'downloading':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-sky-950 text-sky-400 border border-sky-800">
            <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-ping" />
            Downloading
          </span>
        );
      case 'paused':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-950 text-amber-400 border border-amber-800">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            Paused
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            Finished
          </span>
        );
      case 'stopped':
      case 'failed':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-950 text-rose-400 border border-rose-800">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
            Stopped
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800 text-slate-400">
            Queued
          </span>
        );
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-hidden relative">
      {/* Table search & filter header */}
      <div className="p-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search downloads by name, link, or format..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-800 border border-slate-700 rounded-md pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-blue-500 transition-colors"
          />
        </div>

        <div className="flex items-center gap-2 text-slate-400">
          <span className="font-mono text-[11px]">
            Showing <strong className="text-slate-200">{filteredDownloads.length}</strong> items
          </span>
          {selectedIds.length > 0 && (
            <span className="bg-blue-950 text-blue-300 border border-blue-800 px-2 py-0.5 rounded text-[11px] font-medium">
              {selectedIds.length} selected
            </span>
          )}
        </div>
      </div>

      {/* Main Table Container */}
      <div className="flex-1 overflow-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-900/90 sticky top-0 z-10 border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider font-semibold">
            <tr>
              <th className="py-2.5 px-3 w-9 text-center">
                <button
                  onClick={allSelected ? onClearSelection : onSelectAll}
                  className="text-slate-400 hover:text-blue-400 focus:outline-none"
                  title={allSelected ? 'Deselect all' : 'Select all'}
                  aria-label={allSelected ? 'Deselect all downloads' : 'Select all downloads'}
                >
                  {allSelected ? (
                    <CheckSquare className="w-3.5 h-3.5 text-blue-500" />
                  ) : (
                    <EmptySquare className="w-3.5 h-3.5" />
                  )}
                </button>
              </th>
              <th className="py-2.5 px-3">File Name</th>
              <th className="py-2.5 px-3 w-24">Size</th>
              <th className="py-2.5 px-3 w-28 text-center">Status</th>
              <th className="py-2.5 px-3 w-24 text-center">Priority</th>
              <th className="py-2.5 px-3 w-28 text-right">Transfer Rate</th>
              <th className="py-2.5 px-3 w-36">Progress</th>
              <th className="py-2.5 px-3 w-24 text-center">Time Left</th>
              <th className="py-2.5 px-3 w-36 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850">
            {filteredDownloads.length === 0 ? (
              <tr>
                <td colSpan={9} className="py-16 text-center text-slate-500 space-y-2">
                  <div className="w-12 h-12 mx-auto rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-600">
                    <Download className="w-6 h-6" />
                  </div>
                  <p className="text-sm font-medium text-slate-400">No downloads matching criteria</p>
                  <p className="text-xs text-slate-400">
                    Click &quot;Add URL&quot; or &quot;Paste &amp; Download&quot; from the top toolbar to start grabbing files.
                  </p>
                </td>
              </tr>
            ) : (
              filteredDownloads.map((item) => {
                const isSelected = selectedIds.includes(item.id);
                return (
                  <tr
                    key={item.id}
                    onContextMenu={(e) => handleRowContextMenu(e, item)}
                    onDoubleClick={() => onInspectItem(item)}
                    className={`group transition-colors cursor-pointer select-none ${
                      isSelected
                        ? 'bg-blue-950/40 hover:bg-blue-950/60'
                        : 'hover:bg-slate-900/60'
                    }`}
                  >
                    {/* Checkbox */}
                    <td className="py-2 px-3 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleSelect(item.id);
                        }}
                        className="text-slate-500 hover:text-blue-400 focus:outline-none"
                        aria-label={`Select ${item.name}`}
                      >
                        {isSelected ? (
                          <CheckSquare className="w-3.5 h-3.5 text-blue-500" />
                        ) : (
                          <EmptySquare className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </td>

                    {/* File Name + Category */}
                    <td className="py-2 px-3">
                      <div className="flex items-center gap-2.5 max-w-sm xl:max-w-md">
                        <div className="shrink-0 p-1.5 rounded bg-slate-900 border border-slate-800">
                          {getCategoryIcon(item.category)}
                        </div>
                        <div className="truncate">
                          <div className="font-medium text-slate-200 truncate group-hover:text-blue-300 transition-colors">
                            {item.name}
                          </div>
                          <div className="flex items-center gap-2 text-[10px] text-slate-400 truncate">
                            {item.resolution && (
                              <span className="bg-slate-800 text-cyan-300 px-1 rounded font-mono">
                                {item.resolution}
                              </span>
                            )}
                            <span className="truncate">{item.url}</span>
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Size */}
                    <td className="py-2 px-3 font-mono text-[11px] text-slate-300">
                      {formatBytes(item.fileSize)}
                    </td>

                    {/* Status */}
                    <td className="py-2 px-3 text-center">
                      {getStatusBadge(item.status)}
                    </td>

                    {/* Priority Badge */}
                    <td className="py-2 px-3 text-center">
                      {(() => {
                        const pri = item.priority || 'normal';
                        const info = PRIORITY_LABELS[pri];
                        const nextPriority: DownloadPriority =
                          pri === 'high' ? 'normal' : pri === 'normal' ? 'low' : 'high';
                        return (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onChangePriority(item.id, nextPriority);
                            }}
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold border transition-all active:scale-95 ${info.color}`}
                            title={`Priority: ${info.label} (${info.desc}) - Click to toggle priority`}
                          >
                            <span>{info.badge}</span>
                          </button>
                        );
                      })()}
                    </td>

                    {/* Speed */}
                    <td className="py-2 px-3 text-right font-mono text-[11px]">
                      {item.status === 'downloading' ? (
                        <span className="text-cyan-400 font-semibold">{formatSpeed(item.speed)}</span>
                      ) : (
                        <span className="text-slate-600">0 KB/s</span>
                      )}
                    </td>

                    {/* Progress Bar + Percentage */}
                    <td className="py-2 px-3">
                      <div className="space-y-1">
                        <div className="flex justify-between items-center text-[10px] font-mono">
                          <span className="text-slate-400">{item.progress.toFixed(1)}%</span>
                          <span className="text-slate-500 text-[9px]">
                            {formatBytes(item.downloadedBytes)} / {formatBytes(item.fileSize)}
                          </span>
                        </div>
                        <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden flex border border-slate-700/60">
                          <div
                            className={`h-full transition-all duration-300 ${
                              item.status === 'completed'
                                ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                                : item.status === 'paused'
                                ? 'bg-amber-500'
                                : item.status === 'downloading'
                                ? 'bg-gradient-to-r from-blue-500 via-indigo-500 to-cyan-400'
                                : 'bg-rose-500'
                            }`}
                            style={{ width: `${Math.min(item.progress, 100)}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    {/* ETA */}
                    <td className="py-2 px-3 text-center font-mono text-[11px] text-slate-400">
                      {item.status === 'downloading' ? (
                        formatDuration(item.eta)
                      ) : item.status === 'completed' ? (
                        <span className="text-emerald-500 font-medium">Done</span>
                      ) : (
                        <span className="text-slate-600">-</span>
                      )}
                    </td>

                    {/* Quick Row Action Buttons */}
                    <td className="py-2 px-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {/* Pause / Resume */}
                        {item.status === 'downloading' ? (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onTogglePauseItem(item);
                            }}
                            className="p-1 rounded bg-amber-950/80 text-amber-300 hover:bg-amber-900 border border-amber-800 transition-colors"
                            title="Pause Download"
                            aria-label={`Pause download ${item.name}`}
                          >
                            <Pause className="w-3 h-3" />
                          </button>
                        ) : item.status === 'paused' ? (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onTogglePauseItem(item);
                            }}
                            className="p-1 rounded bg-sky-950/80 text-sky-300 hover:bg-sky-900 border border-sky-800 transition-colors"
                            title="Resume Download"
                            aria-label={`Resume download ${item.name}`}
                          >
                            <Play className="w-3 h-3 fill-current" />
                          </button>
                        ) : (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onRedownloadItem(item);
                            }}
                            className="p-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700 transition-colors"
                            title="Re-download"
                            aria-label={`Re-download ${item.name}`}
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                        )}

                        {/* Open / Inspect */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onInspectItem(item);
                          }}
                          className="p-1 rounded bg-blue-950/80 text-blue-300 hover:bg-blue-900 border border-blue-800 transition-colors"
                          title="Open Live IDM Progress & Details"
                          aria-label={`Inspect ${item.name}`}
                        >
                          <ExternalLink className="w-3 h-3" />
                        </button>

                        {/* Save to Disk (if completed) */}
                        {item.status === 'completed' && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onSaveToDisk(item);
                            }}
                            className="p-1 rounded bg-emerald-950/80 text-emerald-300 hover:bg-emerald-900 border border-emerald-800 transition-colors"
                            title="Save file to device disk"
                            aria-label={`Save ${item.name} to disk`}
                          >
                            <Download className="w-3 h-3" />
                          </button>
                        )}

                        {/* Delete */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteItem(item.id);
                          }}
                          className="p-1 rounded bg-slate-900 text-slate-400 hover:text-rose-400 hover:bg-rose-950 border border-slate-800 transition-colors"
                          title="Delete from list"
                          aria-label={`Delete ${item.name}`}
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Floating Shuvo Watermark badge pinned to bottom right of table */}
      <div className="absolute right-4 bottom-4 pointer-events-auto shadow-2xl">
        <div className="bg-slate-900/90 backdrop-blur-md border border-blue-500/50 rounded-xl px-3 py-1.5 flex items-center gap-2 shadow-lg">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-bold text-slate-200">
            👤 <span className="text-emerald-400">Shuvo Bhai</span> | 📱 <span className="text-cyan-300 font-mono">01997966529</span>
          </span>
        </div>
      </div>

      {/* IDM Style Context Menu */}
      {contextMenu.visible && contextMenu.item && (
        <div
          className="fixed z-50 w-52 bg-slate-900 border border-slate-700 rounded-lg shadow-2xl py-1 text-xs text-slate-200"
          style={{ left: contextMenu.x, top: contextMenu.y }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 border-b border-slate-800 truncate">
            {contextMenu.item.name}
          </div>

          <button
            onClick={() => {
              onPasteAndDownload();
              setContextMenu((prev) => ({ ...prev, visible: false }));
            }}
            className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-blue-600 hover:text-white text-left transition-colors"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>📋 Paste & Download</span>
          </button>

          <div className="h-[1px] bg-slate-800 my-1" />

          <button
            onClick={() => {
              onInspectItem(contextMenu.item!);
              setContextMenu((prev) => ({ ...prev, visible: false }));
            }}
            className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-blue-600 hover:text-white text-left transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Open Progress Window</span>
          </button>

          <button
            onClick={() => {
              onOpenFolder();
              setContextMenu((prev) => ({ ...prev, visible: false }));
            }}
            className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-blue-600 hover:text-white text-left transition-colors"
          >
            <FolderOpen className="w-3.5 h-3.5" />
            <span>Open Output Folder</span>
          </button>

          {contextMenu.item.status === 'completed' && (
            <button
              onClick={() => {
                onSaveToDisk(contextMenu.item!);
                setContextMenu((prev) => ({ ...prev, visible: false }));
              }}
              className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-blue-600 hover:text-white text-left transition-colors text-emerald-400 font-medium"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Save File to PC</span>
            </button>
          )}

          <div className="h-[1px] bg-slate-800 my-1" />

          <button
            onClick={() => {
              onTogglePauseItem(contextMenu.item!);
              setContextMenu((prev) => ({ ...prev, visible: false }));
            }}
            className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-blue-600 hover:text-white text-left transition-colors"
          >
            {contextMenu.item.status === 'downloading' ? (
              <>
                <Pause className="w-3.5 h-3.5 text-amber-400" />
                <span>Pause Download</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 text-sky-400" />
                <span>Resume Download</span>
              </>
            )}
          </button>

          <button
            onClick={() => {
              onStopItem(contextMenu.item!);
              setContextMenu((prev) => ({ ...prev, visible: false }));
            }}
            className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-blue-600 hover:text-white text-left transition-colors text-rose-400"
          >
            <Square className="w-3.5 h-3.5" />
            <span>🛑 Stop Download</span>
          </button>

          <button
            onClick={() => {
              onRedownloadItem(contextMenu.item!);
              setContextMenu((prev) => ({ ...prev, visible: false }));
            }}
            className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-blue-600 hover:text-white text-left transition-colors text-amber-400"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>🔄 Re-download</span>
          </button>

          <div className="h-[1px] bg-slate-800 my-1" />

          {/* Queue Priority Selection */}
          <div className="px-3 py-1 text-[10px] uppercase font-bold text-slate-400">
            Set Queue Priority
          </div>
          <button
            onClick={() => {
              onChangePriority(contextMenu.item!.id, 'high');
              setContextMenu((prev) => ({ ...prev, visible: false }));
            }}
            className={`w-full flex items-center justify-between px-3 py-1.5 hover:bg-slate-800 text-left transition-colors ${
              (contextMenu.item.priority || 'normal') === 'high'
                ? 'text-rose-400 font-bold bg-rose-950/30'
                : 'text-slate-300'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <span>🔥</span> High Priority (3x)
            </span>
            {(contextMenu.item.priority || 'normal') === 'high' && <span>✓</span>}
          </button>
          <button
            onClick={() => {
              onChangePriority(contextMenu.item!.id, 'normal');
              setContextMenu((prev) => ({ ...prev, visible: false }));
            }}
            className={`w-full flex items-center justify-between px-3 py-1.5 hover:bg-slate-800 text-left transition-colors ${
              (contextMenu.item.priority || 'normal') === 'normal'
                ? 'text-cyan-400 font-bold bg-cyan-950/30'
                : 'text-slate-300'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <span>⚡</span> Normal Priority (1.5x)
            </span>
            {(contextMenu.item.priority || 'normal') === 'normal' && <span>✓</span>}
          </button>
          <button
            onClick={() => {
              onChangePriority(contextMenu.item!.id, 'low');
              setContextMenu((prev) => ({ ...prev, visible: false }));
            }}
            className={`w-full flex items-center justify-between px-3 py-1.5 hover:bg-slate-800 text-left transition-colors ${
              (contextMenu.item.priority || 'normal') === 'low'
                ? 'text-slate-300 font-bold bg-slate-800/40'
                : 'text-slate-400'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <span>💤</span> Low Priority (0.6x)
            </span>
            {(contextMenu.item.priority || 'normal') === 'low' && <span>✓</span>}
          </button>

          <div className="h-[1px] bg-slate-800 my-1" />

          <button
            onClick={() => {
              onDeleteItem(contextMenu.item!.id);
              setContextMenu((prev) => ({ ...prev, visible: false }));
            }}
            className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-rose-600 hover:text-white text-left transition-colors text-rose-400"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>🗑️ Delete Item</span>
          </button>
        </div>
      )}
    </div>
  );
};
