import React, { useState } from 'react';
import {
  X,
  DownloadCloud,
  ChevronDown,
  Video,
  Music,
  ExternalLink,
  Play,
  Share2,
} from 'lucide-react';

interface BrowserSnifferDemoProps {
  onClose: () => void;
  onSniffDownload: (quality: string, type: 'video' | 'audio') => void;
}

export const BrowserSnifferDemo: React.FC<BrowserSnifferDemoProps> = ({
  onClose,
  onSniffDownload,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs select-none">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden flex flex-col text-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-slate-800 px-4 py-2.5 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ExternalLink className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-bold text-slate-100">
              Browser Video Sniffer Overlay - Shuvo IDM Extension Simulator
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-700 transition-colors"
            aria-label="Close sniffer demo"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content: Simulated Browser Webpage with Video Player */}
        <div className="p-4 space-y-3 text-xs">
          <p className="text-slate-400 leading-normal text-[11px]">
            In Chrome, Edge, and Firefox, the <strong>Shuvo IDM Integration Module</strong> floats automatically on top of videos (YouTube, Facebook, TikTok, Instagram). Try clicking the floating IDM button below:
          </p>

          {/* Simulated Browser Window */}
          <div className="border border-slate-700 rounded-lg overflow-hidden bg-slate-950 shadow-inner">
            {/* Browser Address Bar */}
            <div className="bg-slate-900/90 border-b border-slate-800 px-3 py-1.5 flex items-center gap-2">
              <div className="flex gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
              </div>
              <div className="flex-1 bg-slate-950 border border-slate-800 rounded px-2.5 py-0.5 text-[10px] font-mono text-slate-400 truncate">
                https://www.youtube.com/watch?v=bangla_tech_2026_review
              </div>
            </div>

            {/* Simulated Video Player */}
            <div className="aspect-video w-full bg-slate-900 relative flex items-center justify-center overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80"
                alt="Cyberpunk Video Player"
                className="w-full h-full object-cover opacity-60"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 flex flex-col justify-between p-4">
                {/* Floating IDM Sniffer Button (The Star of the show!) */}
                <div className="flex justify-end relative">
                  <div className="relative">
                    <button
                      onClick={() => setDropdownOpen(!dropdownOpen)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-gradient-to-r from-blue-700 via-indigo-600 to-cyan-600 hover:from-blue-600 hover:to-cyan-500 text-white font-bold text-xs shadow-xl border border-cyan-400/40 hover:scale-105 transition-all cursor-pointer"
                    >
                      <DownloadCloud className="w-4 h-4 text-cyan-200" />
                      <span>Download this video</span>
                      <ChevronDown className="w-3 h-3 text-cyan-200" />
                    </button>

                    {/* Quality Selection Dropdown */}
                    {dropdownOpen && (
                      <div className="absolute right-0 top-full mt-1.5 w-60 bg-slate-900 border border-cyan-500/40 rounded-lg shadow-2xl py-1 z-20 text-xs animate-in fade-in duration-100">
                        <div className="px-3 py-1 text-[10px] font-bold text-cyan-400 uppercase tracking-wider border-b border-slate-800">
                          Shuvo IDM Streams
                        </div>

                        <button
                          onClick={() => {
                            onSniffDownload('1080p FHD (60fps)', 'video');
                            setDropdownOpen(false);
                            onClose();
                          }}
                          className="w-full flex items-center justify-between px-3 py-2 hover:bg-blue-600 text-slate-200 hover:text-white transition-colors text-left"
                        >
                          <div className="flex items-center gap-2">
                            <Video className="w-3.5 h-3.5 text-rose-400" />
                            <span>1080p Full HD (60fps)</span>
                          </div>
                          <span className="font-mono text-[10px] opacity-75">MP4</span>
                        </button>

                        <button
                          onClick={() => {
                            onSniffDownload('720p HD (High)', 'video');
                            setDropdownOpen(false);
                            onClose();
                          }}
                          className="w-full flex items-center justify-between px-3 py-2 hover:bg-blue-600 text-slate-200 hover:text-white transition-colors text-left"
                        >
                          <div className="flex items-center gap-2">
                            <Video className="w-3.5 h-3.5 text-rose-400" />
                            <span>720p HD (Recommended)</span>
                          </div>
                          <span className="font-mono text-[10px] opacity-75">MP4</span>
                        </button>

                        <button
                          onClick={() => {
                            onSniffDownload('4K Ultra HD (2160p)', 'video');
                            setDropdownOpen(false);
                            onClose();
                          }}
                          className="w-full flex items-center justify-between px-3 py-2 hover:bg-blue-600 text-slate-200 hover:text-white transition-colors text-left"
                        >
                          <div className="flex items-center gap-2">
                            <Video className="w-3.5 h-3.5 text-purple-400" />
                            <span>4K Ultra HD (2160p)</span>
                          </div>
                          <span className="font-mono text-[10px] opacity-75">MP4</span>
                        </button>

                        <div className="h-[1px] bg-slate-800 my-1" />

                        <button
                          onClick={() => {
                            onSniffDownload('MP3 Audio (320kbps)', 'audio');
                            setDropdownOpen(false);
                            onClose();
                          }}
                          className="w-full flex items-center justify-between px-3 py-2 hover:bg-emerald-600 text-slate-200 hover:text-white transition-colors text-left"
                        >
                          <div className="flex items-center gap-2">
                            <Music className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Extract MP3 Audio</span>
                          </div>
                          <span className="font-mono text-[10px] opacity-75">320kbps</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Video HUD Bottom */}
                <div className="space-y-1">
                  <div className="text-sm font-bold text-white drop-shadow">
                    Artificial Intelligence in 2026 - Masterclass Video Stream
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-300">
                    <div className="flex items-center gap-3">
                      <Play className="w-3.5 h-3.5 fill-white text-white" />
                      <span>12:45 / 45:10</span>
                    </div>
                    <span className="font-mono text-cyan-300">Auto Sniffer Active</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-800/90 px-4 py-2.5 border-t border-slate-700 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-md bg-slate-700 hover:bg-slate-600 text-slate-200 font-medium transition-all text-xs"
          >
            Close Simulator
          </button>
        </div>
      </div>
    </div>
  );
};
