import React from 'react';
import { DownloadCloud, Volume2, VolumeX, ShieldCheck, Clock, ExternalLink, HelpCircle, PhoneCall } from 'lucide-react';
import { LicenseState } from '../types/idm';

interface TitleBarProps {
  license: LicenseState;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenLicense: () => void;
  onOpenHelp: () => void;
  onOpenSnifferDemo: () => void;
}

export const TitleBar: React.FC<TitleBarProps> = ({
  license,
  soundEnabled,
  onToggleSound,
  onOpenLicense,
  onOpenHelp,
  onOpenSnifferDemo,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-200 select-none px-3 py-2 flex items-center justify-between text-xs">
      {/* Left: Brand & Title */}
      <div className="flex items-center gap-2.5">
        <div className="w-6 h-6 rounded bg-gradient-to-br from-blue-600 via-indigo-600 to-cyan-500 flex items-center justify-center shadow-sm">
          <DownloadCloud className="w-3.5 h-3.5 text-white" />
        </div>
        <div className="flex items-center gap-1.5 font-semibold tracking-wide">
          <span className="text-blue-400">Shuvo IDM</span>
          <span className="text-slate-400 font-normal">| Internet Download Manager Pro</span>
          <span className="bg-blue-950 text-blue-300 border border-blue-800/80 px-1.5 py-0.5 rounded text-[10px] font-mono">
            v2026.1
          </span>
        </div>
      </div>

      {/* Middle: Developer contact badge */}
      <div className="hidden md:flex items-center gap-2 bg-slate-800/80 border border-slate-700/80 px-2.5 py-1 rounded-full text-slate-300">
        <PhoneCall className="w-3 h-3 text-emerald-400" />
        <span className="font-medium text-emerald-400">SM Shuvo</span>
        <span className="text-slate-500">|</span>
        <a 
          href="tel:01997966529" 
          className="font-mono text-cyan-300 hover:text-cyan-200 hover:underline transition-colors"
          title="Call Developer SM Shuvo"
        >
          01997966529
        </a>
      </div>

      {/* Right: Quick actions & License pill */}
      <div className="flex items-center gap-2">
        <button
          onClick={onOpenSnifferDemo}
          className="flex items-center gap-1 px-2 py-1 rounded bg-indigo-950/80 text-indigo-300 hover:bg-indigo-900 border border-indigo-800/60 transition-colors"
          title="Try Browser Video Sniffer Overlay"
        >
          <ExternalLink className="w-3 h-3 text-indigo-400" />
          <span className="hidden sm:inline">Extension Sniffer</span>
        </button>

        <button
          onClick={onToggleSound}
          className={`p-1.5 rounded border transition-colors ${
            soundEnabled
              ? 'bg-slate-800 border-slate-700 text-blue-400 hover:bg-slate-700'
              : 'bg-slate-800/50 border-slate-800 text-slate-500 hover:text-slate-400'
          }`}
          title={soundEnabled ? 'Mute IDM completion sounds' : 'Enable IDM completion sounds'}
          aria-label={soundEnabled ? 'Mute IDM sound effects' : 'Enable IDM sound effects'}
        >
          {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
        </button>

        <button
          onClick={onOpenHelp}
          className="p-1.5 rounded bg-slate-800 border border-slate-700 text-slate-400 hover:text-slate-200 hover:bg-slate-700 transition-colors"
          title="Help & Shortcuts"
          aria-label="Open help and keyboard shortcuts"
        >
          <HelpCircle className="w-3.5 h-3.5" />
        </button>

        {/* License Pill */}
        <button
          onClick={onOpenLicense}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded font-medium border transition-all ${
            license.status === 'ACTIVATED'
              ? 'bg-emerald-950/80 border-emerald-700 text-emerald-300 hover:bg-emerald-900'
              : 'bg-amber-950/80 border-amber-700 text-amber-300 hover:bg-amber-900 animate-pulse'
          }`}
          title="Click to view license details and activate key"
        >
          {license.status === 'ACTIVATED' ? (
            <>
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>ACTIVATED ({license.info})</span>
            </>
          ) : (
            <>
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>TRIAL ({license.trialDaysLeft} Days Left)</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
