import React from 'react';
import { X, HelpCircle, Keyboard, Phone, ShieldCheck, Zap } from 'lucide-react';

interface HelpModalProps {
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs select-none">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden flex flex-col text-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-slate-800 px-4 py-2.5 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-blue-400" />
            <span className="text-xs font-bold text-slate-100">
              Shuvo IDM User Guide &amp; Keyboard Shortcuts
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-700 transition-colors"
            aria-label="Close user guide"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 text-xs">
          {/* Shortcuts */}
          <div className="space-y-2">
            <div className="font-bold text-slate-300 flex items-center gap-1.5 text-[11px]">
              <Keyboard className="w-3.5 h-3.5 text-cyan-400" />
              <span>Keyboard &amp; Mouse Controls</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="bg-slate-950 p-2 rounded border border-slate-800 flex justify-between items-center">
                <span className="text-slate-400">Add New URL:</span>
                <kbd className="bg-slate-800 px-1.5 py-0.5 rounded text-cyan-300 font-mono">Alt + A</kbd>
              </div>
              <div className="bg-slate-950 p-2 rounded border border-slate-800 flex justify-between items-center">
                <span className="text-slate-400">Paste &amp; Download:</span>
                <kbd className="bg-slate-800 px-1.5 py-0.5 rounded text-cyan-300 font-mono">Ctrl + V</kbd>
              </div>
              <div className="bg-slate-950 p-2 rounded border border-slate-800 flex justify-between items-center">
                <span className="text-slate-400">Inspect Download:</span>
                <span className="text-cyan-300 font-mono">Double Click</span>
              </div>
              <div className="bg-slate-950 p-2 rounded border border-slate-800 flex justify-between items-center">
                <span className="text-slate-400">Context Menu:</span>
                <span className="text-cyan-300 font-mono">Right Click</span>
              </div>
            </div>
          </div>

          {/* Core Features */}
          <div className="space-y-2">
            <div className="font-bold text-slate-300 flex items-center gap-1.5 text-[11px]">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Key Capabilities</span>
            </div>
            <ul className="space-y-1.5 text-[11px] text-slate-400 list-disc list-inside">
              <li>
                <strong className="text-slate-200">8-Thread Dynamic Segmentation:</strong> Splits each file into 8 concurrent chunks to maximize transfer speeds.
              </li>
              <li>
                <strong className="text-slate-200">Video &amp; Audio Sniffer:</strong> Detects YouTube, Facebook Reels, TikTok, and Vimeo streaming links with custom resolutions up to 4K and MP3 320kbps.
              </li>
              <li>
                <strong className="text-slate-200">Batch Multi-Link Downloader:</strong> Queues hundreds of URLs simultaneously with bandwidth throttling.
              </li>
              <li>
                <strong className="text-slate-200">Cryptographic Licensing:</strong> HMAC-SHA256 signature verification tied to unique hardware Machine IDs.
              </li>
            </ul>
          </div>

          {/* Author Card */}
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-bold text-emerald-400 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Created by SM Shuvo
              </span>
              <a
                href="tel:01997966529"
                className="font-mono text-cyan-300 font-bold hover:underline flex items-center gap-1"
              >
                <Phone className="w-3 h-3 text-cyan-400" />
                01997966529
              </a>
            </div>
            <p className="text-[10px] text-slate-400">
              For commercial distribution, lifetime license activation keys, and custom modules, contact developer SM Shuvo directly.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-800/90 px-4 py-2.5 border-t border-slate-700 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-md bg-slate-700 hover:bg-slate-600 text-slate-200 font-medium transition-all text-xs"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
