import React, { useState } from 'react';
import {
  X,
  Webhook,
  Code2,
  Send,
  Check,
  Copy,
  Terminal,
  Cpu,
  Radio,
} from 'lucide-react';

interface ApiExtensionModalProps {
  onClose: () => void;
  onSendTestDownload: (url: string) => void;
}

export const ApiExtensionModal: React.FC<ApiExtensionModalProps> = ({
  onClose,
  onSendTestDownload,
}) => {
  const [testUrl, setTestUrl] = useState('https://www.youtube.com/watch?v=3JZ_D3ELwOQ');
  const [copiedCurl, setCopiedCurl] = useState(false);
  const [sentToast, setSentToast] = useState(false);

  const curlCommand = `curl -X POST http://localhost:5000/download \\
  -H "Content-Type: application/json" \\
  -d '{"url": "${testUrl}"}'`;

  const handleCopyCurl = () => {
    navigator.clipboard.writeText(curlCommand);
    setCopiedCurl(true);
    setTimeout(() => setCopiedCurl(false), 2000);
  };

  const handleTestSend = () => {
    onSendTestDownload(testUrl);
    setSentToast(true);
    setTimeout(() => {
      setSentToast(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs select-none">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden flex flex-col text-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-slate-800 px-4 py-2.5 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Webhook className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-bold text-slate-100">
              Browser Extension API Server (Flask Port 5000)
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-700 transition-colors"
            aria-label="Close API modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 text-xs">
          {/* Status info */}
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              <div>
                <div className="font-semibold text-slate-200">Local Bridge Server: ONLINE</div>
                <div className="text-[10px] text-slate-400 font-mono">
                  Listening on http://localhost:5000/download
                </div>
              </div>
            </div>
            <span className="font-mono text-[10px] bg-slate-900 border border-slate-700 text-cyan-300 px-2 py-0.5 rounded">
              CORS Enabled
            </span>
          </div>

          <p className="text-slate-400 text-[11px] leading-relaxed">
            Chrome and Firefox extensions send intercepted download requests directly to Shuvo IDM using HTTP POST requests:
          </p>

          {/* cURL Snippet */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                cURL Integration Payload:
              </span>
              <button
                onClick={handleCopyCurl}
                className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300"
              >
                {copiedCurl ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                <span>{copiedCurl ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 font-mono text-[10px] text-cyan-300 overflow-x-auto select-all">
              {curlCommand}
            </pre>
          </div>

          {/* Test Sender */}
          <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 space-y-2">
            <div className="font-medium text-slate-300 flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-emerald-400" />
              <span>Simulate Browser Extension Trigger:</span>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={testUrl}
                onChange={(e) => setTestUrl(e.target.value)}
                placeholder="https://..."
                className="flex-1 bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 font-mono text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              />
              <button
                onClick={handleTestSend}
                className="flex items-center gap-1 px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs transition-all active:scale-95"
              >
                <Send className="w-3 h-3" />
                <span>Send to IDM</span>
              </button>
            </div>
            {sentToast && (
              <div className="text-[11px] font-bold text-emerald-400 flex items-center gap-1 animate-pulse">
                ✓ HTTP 200 OK: Link successfully dispatched to Shuvo IDM queue!
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-800/90 px-4 py-2.5 border-t border-slate-700 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-md bg-slate-700 hover:bg-slate-600 text-slate-200 font-medium transition-all text-xs"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
