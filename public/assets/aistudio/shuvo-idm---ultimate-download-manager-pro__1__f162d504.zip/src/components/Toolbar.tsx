import {
  Plus,
  ClipboardPaste,
  Layers,
  KeyRound,
  Square,
  RotateCcw,
  Trash2,
  Eraser,
  FolderOpen,
  FolderCog,
  Gauge,
  Webhook,
  Globe,
  ListOrdered,
} from 'lucide-react';
import { ProxyConfig } from '../types/idm';

interface ToolbarProps {
  onAddUrl: () => void;
  onPasteAndDownload: () => void;
  onMultiLink: () => void;
  onActivateKey: () => void;
  onStopSelected: () => void;
  onRedownloadSelected: () => void;
  onDeleteSelected: () => void;
  onClearAll: () => void;
  onOpenFolder: () => void;
  onChangeFolder: () => void;
  onOpenApiModal: () => void;
  onOpenProxyModal: () => void;
  onOpenSmartQueue: () => void;
  activeQueueCount: number;
  maxConcurrent: number;
  queueEnabled: boolean;
  proxyConfig: ProxyConfig;
  hasSelection: boolean;
  saveFolder: string;
  speedLimit: string;
  onChangeSpeedLimit: (limit: string) => void;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  onAddUrl,
  onPasteAndDownload,
  onMultiLink,
  onActivateKey,
  onStopSelected,
  onRedownloadSelected,
  onDeleteSelected,
  onClearAll,
  onOpenFolder,
  onChangeFolder,
  onOpenApiModal,
  onOpenProxyModal,
  onOpenSmartQueue,
  activeQueueCount,
  maxConcurrent,
  queueEnabled,
  proxyConfig,
  hasSelection,
  saveFolder,
  speedLimit,
  onChangeSpeedLimit,
}) => {
  return (
    <div className="bg-slate-800/90 border-b border-slate-700/80 px-3 py-2 flex flex-wrap items-center justify-between gap-2 shadow-inner">
      {/* Primary Actions Group */}
      <div className="flex flex-wrap items-center gap-1.5">
        <button
          onClick={onAddUrl}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs shadow transition-all active:scale-95"
          title="Add single URL to download"
        >
          <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
          <span>Add URL</span>
        </button>

        <button
          onClick={onPasteAndDownload}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-sky-600 hover:bg-sky-500 text-white font-medium text-xs shadow transition-all active:scale-95"
          title="Paste URL from clipboard & start immediately"
        >
          <ClipboardPaste className="w-3.5 h-3.5" />
          <span>Paste & Download</span>
        </button>

        <button
          onClick={onMultiLink}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-purple-600 hover:bg-purple-500 text-white font-medium text-xs shadow transition-all active:scale-95"
          title="Batch download multiple URLs"
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Multi-Link</span>
        </button>

        <button
          onClick={onActivateKey}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs shadow transition-all active:scale-95"
          title="Activate License Key"
        >
          <KeyRound className="w-3.5 h-3.5" />
          <span>Activate Key</span>
        </button>

        <div className="h-5 w-[1px] bg-slate-700 mx-1 hidden sm:block" />

        {/* Selected Items Controls */}
        <button
          onClick={onStopSelected}
          disabled={!hasSelection}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all ${
            hasSelection
              ? 'bg-rose-700 hover:bg-rose-600 text-white cursor-pointer active:scale-95'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
          }`}
          title="Stop selected active download"
        >
          <Square className="w-3 h-3 fill-current" />
          <span>Stop</span>
        </button>

        <button
          onClick={onRedownloadSelected}
          disabled={!hasSelection}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all ${
            hasSelection
              ? 'bg-amber-700 hover:bg-amber-600 text-white cursor-pointer active:scale-95'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
          }`}
          title="Re-download selected file"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Re-download</span>
        </button>

        <button
          onClick={onDeleteSelected}
          disabled={!hasSelection}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all ${
            hasSelection
              ? 'bg-red-800 hover:bg-red-700 text-white cursor-pointer active:scale-95'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
          }`}
          title="Delete selected from list"
        >
          <Trash2 className="w-3 h-3" />
          <span>Delete</span>
        </button>

        <button
          onClick={onClearAll}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-medium transition-all active:scale-95 border border-slate-600"
          title="Clear all completed or inactive downloads"
        >
          <Eraser className="w-3 h-3" />
          <span>Clear All</span>
        </button>

        <button
          onClick={onOpenApiModal}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-slate-700/80 hover:bg-slate-600 text-cyan-300 text-xs font-medium transition-all border border-cyan-800/50"
          title="Browser Extension Flask API Server Integration"
        >
          <Webhook className="w-3 h-3 text-cyan-400" />
          <span className="hidden lg:inline">Flask API</span>
        </button>

        <button
          onClick={onOpenProxyModal}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all border ${
            proxyConfig.enabled
              ? 'bg-cyan-950/90 border-cyan-500 text-cyan-300 hover:bg-cyan-900 shadow-sm'
              : 'bg-slate-700/80 hover:bg-slate-600 border-slate-600 text-slate-300'
          }`}
          title={
            proxyConfig.enabled
              ? `Proxy Active: ${proxyConfig.protocol.toUpperCase()}://${proxyConfig.host}:${proxyConfig.port} (${proxyConfig.status})`
              : 'Configure HTTP/SOCKS Proxy'
          }
        >
          <Globe
            className={`w-3.5 h-3.5 ${
              proxyConfig.enabled ? 'text-cyan-400 animate-pulse' : 'text-slate-400'
            }`}
          />
          <span>Proxy</span>
          {proxyConfig.enabled && (
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                proxyConfig.status === 'connected' ? 'bg-emerald-400' : 'bg-cyan-400'
              }`}
            />
          )}
        </button>

        <button
          onClick={onOpenSmartQueue}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all border ${
            queueEnabled
              ? 'bg-indigo-950/90 border-indigo-500 text-indigo-300 hover:bg-indigo-900 shadow-sm'
              : 'bg-slate-700/80 hover:bg-slate-600 border-slate-600 text-slate-300'
          }`}
          title={`Smart Queue: ${queueEnabled ? 'Active' : 'Disabled'} (${activeQueueCount}/${maxConcurrent} active slots)`}
        >
          <ListOrdered className="w-3.5 h-3.5 text-indigo-400" />
          <span>Smart Queue</span>
          <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-indigo-900/80 text-indigo-200 border border-indigo-700/50">
            {activeQueueCount}/{maxConcurrent}
          </span>
        </button>
      </div>

      {/* Right Controls: Folder & Speed limiter */}
      <div className="flex items-center gap-2 text-xs">
        {/* Speed limiter */}
        <div className="flex items-center gap-1.5 bg-slate-900/90 border border-slate-700 px-2 py-1 rounded-md text-slate-300">
          <Gauge className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-[11px] text-slate-400 hidden xl:inline">Speed:</span>
          <select
            value={speedLimit}
            onChange={(e) => onChangeSpeedLimit(e.target.value)}
            className="bg-transparent text-cyan-300 font-mono text-xs focus:outline-none cursor-pointer"
            aria-label="Download Speed Limit"
          >
            <option value="Unlimited" className="bg-slate-900 text-slate-200">Unlimited</option>
            <option value="500 KB/s" className="bg-slate-900 text-slate-200">500 KB/s</option>
            <option value="1 MB/s" className="bg-slate-900 text-slate-200">1 MB/s</option>
            <option value="5 MB/s" className="bg-slate-900 text-slate-200">5 MB/s</option>
            <option value="10 MB/s" className="bg-slate-900 text-slate-200">10 MB/s</option>
          </select>
        </div>

        {/* Folder management */}
        <div className="flex items-center gap-1">
          <button
            onClick={onOpenFolder}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-emerald-700 hover:bg-emerald-600 text-white font-medium transition-all active:scale-95 shadow-sm"
            title="Open default download folder"
          >
            <FolderOpen className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Open Folder</span>
          </button>
          <button
            onClick={onChangeFolder}
            className="p-1.5 rounded-md bg-slate-700 hover:bg-slate-600 text-slate-300 border border-slate-600 transition-colors"
            title={`Change download directory (Current: ${saveFolder})`}
            aria-label="Change download folder location"
          >
            <FolderCog className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
